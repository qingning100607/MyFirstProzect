SKIPMOUNT=false
#是否安装模块后自动关闭，改为faslse，安装后不会自动勾选启用

PROPFILE=true
#是否使用common/system.prop文件

POSTFSDATA=false
#是否使用post-fs-data脚本执行文件

LATESTARTSERVICE=true
#是否在开机时候允许允许common/service.sh中脚本

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
"

Start_Time=$(date "+%Y-%m-%d %H:%M:%S")
Print_Time=$(date "+%m.%d")

# 设定module.prop
id=xiaomi13pppp
name="Xiaomi 13Pro"
version=v5.2.0
versionCode=1
author=我不想要分开
description="心掏出来给你，你嫌它血腥💔"

Ver=版本：$version，刷入时间：$Print_Time


# 输出module.prop
echo "id=$id
name=$name
version=$Ver
versionCode=$versionCode
author=$author
description=$description" > $TMPDIR/module.prop

#获取模块信息
 MODNAME="`grep_prop name $TMPDIR/module.prop`"
 MODAUTHOR="`grep_prop author $TMPDIR/module.prop`"
 MODdescription="`grep_prop description $TMPDIR/module.prop`"
 #获取系统信息
 device="`getprop ro.product.device`"
 Version="`getprop ro.build.version.incremental`"
 Android="`getprop ro.build.version.release`"
 Manufacturer="`getprop ro.product.manufacturer`"
 
 ui_print ""
 ui_print "- 模块相关信息 -"
 ui_print "- 模块: $MODNAME"
 ui_print "- 作者: $MODAUTHOR"
 ui_print ""
 ui_print "- 设备相关信息 -"
 ui_print "- 设备制造商: $Manufacturer"
 ui_print "- 设备代号: $device"
 ui_print "- 安卓版本: Android $Android"
 ui_print "- MIUI版本: $Version"
 ui_print ""
 ui_print "- 正在前往刷机交流群"
 ui_print ""

  coolapkTesting=`pm list package | grep -w 'com.tencent.mobileqq'`
  if [[ "$coolapkTesting" != "" ]];then
  am start -d 'mqq://card/show_pslcard?src_type=internal&version=1&uin=948634109&card_type=group&source=qrcode' >/dev/null 2>&1
  fi
  
rm -rf /data/system/package_cache/*

#释放文件，普通shell命令
on_install() {
  ui_print "- 释放文件中..."
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
#设置权限
}
